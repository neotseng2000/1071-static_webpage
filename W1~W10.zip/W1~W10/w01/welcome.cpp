#include<stdio.h>

int main()
{
	printf("Welcome to C programming\n");
	printf("my name is �����s\nmy English name is Wade\nmy student number is 407410355");
	return 0;
}
